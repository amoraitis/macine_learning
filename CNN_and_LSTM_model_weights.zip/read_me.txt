use 

checkpoint_path_cnn = "CNN_weights_path"
checkpoint_path_lstm = "LSTM_weights_path"

model.load_weights(checkpoint_path_cnn)
model2.load_weights(checkpoint_path_lstm)

To load weights